-- DML

-- INSERT

-- INSERT VALUES
INSERT INTO sales.Orders(orderdate, empid, custid)
VALUES ('20210101', 3, 2)

select * from t1;

insert into t1 values (7, 'c', 40)
insert into t1(id, name) values (8, 'd')

insert into t1(id, name) 
values (9, 'e'),(19, 'ee'),(199, 'eee')

-- INSERT SELECT (enqueu)
insert into t1(id, name)
select id, name from t1
where id > 5

-- INSERT EXEC
CREATE PROC sales.getorders 
@country as varchar(50)
as
select orderid, orderdate, empid, custid
from sales.Orders
where shipcountry = @country

exec sales.getorders @country='France'

create table myorders 
(orderid int, orderdate date, empid int, custid int)

insert into myorders(orderid, orderdate, empid, custid)
exec sales.getorders @country='France'

select * from myorders

-- SELECT INTO
DROP TABLE mybackup;

SELECT *
into mybackup
from sales.orders;

select * from mybackup

truncate table t1

insert into t1 values (1, 'a', 40)
insert into t1 values (2, 'b', 80)

select * from t1

-- DELETE
DELETE FROM t1
WHERE id>2

TRUNCATE TABLE T1

-- DELETE based on join
delete from o
FROM sales.Orders as o
join sales.Customers as c
on o.custid = c.custid
WHERE c.country = 'USA'

-- or the following
DELETE FROM sales.Orders
where exists (
	select * from sales.Customers c
	where Orders.custid = c.custid and c.country = 'USA'
)

-- UPDATE
UPDATE sales.OrderDetails
	set discount = discount +  0.05 
where productid=51
 
--and based on join
UPDATE od
	set discount = discount +  0.05 
FROM sales.OrderDetails as od
join sales.Orders as o
on od.orderid = o.orderid
where o.custid = 1

-- INSERT/UPDATE/DELETE AUTO COMMIT (in sql server)

-- OUTPUT clause
create table t2 (
	keycol int not null identity(1, 1) primary key,
	datacol varchar(50) not null
)

-- INSERT + OUTPUT
INSERT INTO T2(datacol)
OUTPUT inserted.keycol, inserted.datacol
select lastname from hr.Employees

-- DELETE + OUTPUT
DELETE FROM T2
OUTPUT deleted.keycol, deleted.datacol
WHERE datacol like 'D%'

-- UPDATE + OUTPUT
UPDATE T2
	SET datacol = lower(DATACOL)
OUTPUT
	inserted.datacol AS NEW, deleted.datacol AS OLD

-- MERGE (upsert) insert+update
/*
	boston
	1 a
	2 bb
	3 c 

				roma
				1 a
				2 bb
				3 c
*/





















