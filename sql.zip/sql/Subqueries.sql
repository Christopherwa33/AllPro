-- Nested queries/Subqueries

-- Self-contained / Correlated

-- Self-contained

-- wrong
select * from sales.Orders
where orderid=max(orderid)

select * from sales.Orders
where orderid = (select max(orderid) from sales.Orders)

-- wrong..returned more than 1 value
select * from sales.Orders
where empid = (select e.empid from hr.Employees e where lastname like 'D%')

-- subqueries vs join

-- subqueries columns from 1 table (semi-join)
select orderid from sales.Orders
where empid in (select e.empid from hr.Employees e where lastname like 'D%')

select orderid from hr.Employees as e
inner join sales.Orders as o
on e.empid = o.empid
where e.lastname like 'D%'

select orderid from sales.Orders
where empid not in (select e.empid from hr.Employees e where lastname like 'D%')

-- Correlated
select custid, orderid, orderdate
from sales.Orders as o1
where orderid = (
	select max(o2.orderid) from sales.Orders as o2
	where o2.custid = o1.custid
)
order by custid

select max(o2.orderid) from sales.Orders as o2
	where o2.custid = 79

select custid, orderid, orderdate
from sales.Orders as o1
where orderid=10967


/*
A
id name
1   a	
2   b	<-

B
id	name
1	aa
2	bb

select * from A where id =(select id from B where B.id=2)

1 a
2 b
*/

-- exists PREDICATE
select * from sales.Customers c
where country='SPAIN' and 0 !=(
select count(*) from sales.Orders where custid=c.custid
)

select * from sales.Customers c
where country='SPAIN' and exists (
select * from sales.Orders where custid=c.custid
)

select * from sales.Orders where custid=22

select * from [Sales].[OrderTotalsByYear]

2014	-	9581	9581
2015	-	25489	35070
2016	-	16247	51317

select orderyear, qty,  (
	select sum(o2.qty) from sales.[OrderTotalsByYear] as o2
	where o2.orderyear <= o1.orderyear
) as runqty
from [Sales].[OrderTotalsByYear] as o1
order by orderyear

select * from sales.[OrderTotalsByYear]
order by orderyear





