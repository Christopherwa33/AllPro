import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-special-div',
  templateUrl: './special-div.component.html',
  styleUrls: ['./special-div.component.css']
})
export class SpecialDivComponent implements OnInit, OnChanges, OnDestroy {

  @Input()
  public counter: number = 0;

  @Output()
  public counterChange: EventEmitter<number> = new EventEmitter<number>();

  constructor() { }
  
  ngOnDestroy(): void {
    console.log('Special DIV component destroyed');
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('Special DIV component updated');
  }

  ngOnInit(): void {
    console.log('Special DIV component initialized');
  }

  public incrementCounter() {
    this.counter++;
    this.counterChange.emit(this.counter);
  }

}
