-- Table expression

-- 1. Derived table (subqueries in FROM, CTE)
-- 2. Views
-- 3. Inline functions


-- 1. Derived table (subqueries in FROM, CTE)

-- subqueries in FROM
select * from (
select custid, companyname from sales.Customers 
where country='USA'
) AS usaCust;

-- wrong..alias not recognized
select year(orderdate) as orderyear, 
count(custid) as numcusts
from sales.Orders
group by orderyear

-- solution using subqueries in from
select orderyear, count(distinct custid) as numcusts
from (
select year(orderdate) as orderyear, 
custid
from sales.Orders
) as D
group by orderyear

-- Using arguments
-- thanks to T-SQL

select orderyear, count(distinct custid) as numcusts
from (
select year(orderdate) as orderyear, 
custid
from sales.Orders
where empid = 1
) as D
group by orderyear

declare @empid as int = 3;

select orderyear, count(distinct custid) as numcusts
from (
select year(orderdate) as orderyear, 
custid
from sales.Orders
where empid = @empid
) as D
group by orderyear

-- CTE (Common Table Expressions)
-- MATERIALIZED
WITH USACusts AS (
select custid, companyname from sales.Customers 
where country='USA'
)
select * from USACusts;

declare @country as varchar(50) = 'USA';

WITH USACusts(cid, cname) AS (
select custid, companyname from sales.Customers 
where country=@country
)
select cid, cname from USACusts;

-- Multiple CTEs
WITH c1 as (
select * from sales.Orders
),
c2 as (
select * from c1
)
select * from c2

-- mandatory to use CTEs
WITH YearlyCount as (
	select year(orderdate) as orderyear
	, count(distinct custid) as numcusts
	from sales.Orders
	group by year(orderdate)
)
select 
	cur.orderyear
	, cur.numcusts
	, prv.numcusts
	, cur.numcusts - prv.numcusts as growth 
from YearlyCount as Cur
left outer join YearlyCount as Prv
on cur.orderyear = prv.orderyear + 1

-- Recursive CTE 
select * from hr.Employees

with EmpsCTE as 
(
	select empid, mgrid, firstname, lastname
	from hr.Employees
	where empid = 2
	UNION ALL
	select c.empid, c.mgrid, c.firstname, c.lastname
	from EmpsCTE AS P
	JOIN HR.Employees AS C
	ON C.mgrid = P.EMPID
)
select empid, mgrid, firstname, lastname
from empscte

-- Views

CREATE VIEW Sales.USACust
as
select * from sales.Customers
where country = 'USA';
-- order by region;

select * from sales.USACust


ALTER VIEW Sales.USACust
as
select TOP(100) PERCENT * from sales.Customers
where country = 'USA'
ORDER BY REGION;

ALTER VIEW Sales.USACust
as
select custid, companyname from sales.Customers
where country = 'USA';

-- sales.customers (TABLE)	x no privileges 
-- sales.customersV (View)  v

create table t1 (
	id int not null
	, name varchar(50) null
	, age int null
)

create view t1v
as
select * from t1
where id > 5;

select * from t1v;

-- dml on view
insert into t1v values (1, 'a', 20)
insert into t1v values (6, 'b', 30)

-- view constraint
alter view t1v
as
select * from t1
where id > 5
with check option;

insert into t1v values (2, 'a', 20)

-- Inline functions (TVF) - T-SQL
CREATE FUNCTION dbo.GetCustOrders(@cid as int)
RETURNS TABLE
AS
RETURN select * from sales.Orders where custid=@cid;

SELECT * FROM dbo.GetCustOrders(1) AS o

SELECT o.orderid, od.productid 
FROM dbo.GetCustOrders(2) AS o
join sales.OrderDetails as od
on o.orderid = od.orderid



































