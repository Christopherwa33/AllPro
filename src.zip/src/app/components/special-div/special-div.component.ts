import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-special-div',
  templateUrl: './special-div.component.html',
  styleUrls: ['./special-div.component.css']
})
export class SpecialDivComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
