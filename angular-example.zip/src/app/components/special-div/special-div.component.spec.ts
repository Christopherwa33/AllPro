import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialDivComponent } from './special-div.component';

describe('SpecialDivComponent', () => {
  let component: SpecialDivComponent;
  let fixture: ComponentFixture<SpecialDivComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpecialDivComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialDivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
