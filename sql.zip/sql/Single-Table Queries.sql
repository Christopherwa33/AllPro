use TSQLV4

-- 
/*

*/

-- DDL Data Definition Language (CREATE/ALTER/DROP/TRUNCATE) - auto commit
-- DML Data Manipulation Language (INSERT/UPDATE/DELETE/MERGE) - no auto commit
-- DQL Data Query Language (SELECT)
-- DCL Data Control Language (GRANT, REVOKE, COMMIT, ROLLBACK, SAVEPOINT)

-- Sample query
SELECT 
	empid, YEAR(orderdate) AS orderyear, COUNT(*) as numorders
FROM 
	Sales.Orders
WHERE
	custid = 71
GROUP BY 
	empid, YEAR(orderdate)
HAVING 
	COUNT(*) > 1
ORDER BY 
	empid, orderyear;

/*
1. FROM
2. WHERE
3. GROUP BY
4. HAVING
5. SELECT
6. ORDER BY
*/

-- FROM
SELECT orderid, custid, empid, orderdate, freight
FROM sales.orders;

-- WHERE
SELECT orderid, custid, empid, orderdate, freight
FROM SALES.Orders
WHERE custid = 71

SELECT orderid, custid, empid, orderdate, freight
FROM SALES.Orders
WHERE custid = 71 or custid = 72

-- GROUP BY

SELECT 
	empid
	, YEAR(orderdate) as orderyear
	, count(*) as numorders
FROM SALES.Orders
GROUP BY empid, YEAR(orderdate)

SELECT 
	empid
	, YEAR(orderdate) as orderyear
	, count(custid) as numcust
FROM SALES.Orders
GROUP BY empid, YEAR(orderdate)

SELECT 
	empid
	, YEAR(orderdate) as orderyear
	, count(distinct custid) as numcust
FROM SALES.Orders
GROUP BY empid, YEAR(orderdate)

insert into testnull values (4, 'alberto', 16)
select * from testnull;

-- rows counting
select count(*) from testnull;

-- rows counting not null
select count(age) from testnull;

-- rows counting not null no duplicates
select count(distinct age) from testnull;


-- HAVING
SELECT 
	empid
	, YEAR(orderdate) as orderyear
	, count(distinct custid) as numcust
FROM SALES.Orders
GROUP BY empid, YEAR(orderdate)
HAVING COUNT(*) > 1 OR 2=2

-- SELECT
SELECT orderid orderdate
from sales.Orders

-- 1. invalid reference
SELECT orderid, year(orderdate) as orderyear
from sales.Orders
where orderyear > 2006

SELECT orderid, year(orderdate) as orderyear
from sales.Orders
where year(orderdate) > 2006

-- 2. invalid reference
SELECT empid, year(orderdate) as orderyear, count(*) as numorders
from sales.Orders
group by empid, year(orderdate)
HAVING numorders>1

SELECT empid, year(orderdate) as orderyear, count(*) as numorders
from sales.Orders
group by empid, year(orderdate)
HAVING count(*)>1

-- duplicate rows

SELECT empid, year(orderdate) as orderyear
from sales.Orders
where custid = 71
order by empid;

SELECT DISTINCT empid, year(orderdate) as orderyear
from sales.Orders
where custid = 71
order by empid;

SELECT empid eid, eid+1	-- no back/forward reference
from sales.Orders
where custid = 71;

-- ORDER BY
SELECT 
	empid, YEAR(orderdate) AS orderyear, COUNT(*) as numorders
FROM 
	Sales.Orders
WHERE
	custid = 71
GROUP BY 
	empid, YEAR(orderdate)
HAVING 
	COUNT(*) > 1
ORDER BY 
	empid, orderyear;


SELECT 
	empid, YEAR(orderdate) AS orderyear, COUNT(*) as numorders
FROM 
	Sales.Orders
WHERE
	custid = 71
GROUP BY 
	empid, YEAR(orderdate)
HAVING 
	COUNT(*) > 1
ORDER BY 
	1 asc, 2 desc;


SELECT 
	empid, YEAR(orderdate) AS orderyear, COUNT(*) as numorders
FROM 
	Sales.Orders
WHERE
	custid = 71
GROUP BY 
	empid, YEAR(orderdate)
HAVING 
	COUNT(*) > 1
ORDER BY 
	shipcity;	-- invalid

-- TOP / OFFSET-FETCH Filters
SELECT TOP(5) orderid, orderdate	-- SAMPLE based on records
from sales.Orders
ORDER BY orderdate DESC;

SELECT TOP(1) PERCENT orderid, orderdate	-- SAMPLE based on percent
from sales.Orders
ORDER BY orderdate DESC;

SELECT TOP(5) orderid, orderdate, custid, empid
from sales.Orders
ORDER BY orderdate DESC;

SELECT TOP(5) WITH TIES orderid, orderdate, custid, empid
from sales.Orders
ORDER BY orderdate DESC;

SELECT orderid, orderdate, custid, empid
from sales.Orders
ORDER BY orderdate DESC
OFFSET 810 ROWS FETCH NEXT 25 ROWS ONLY;

-- Predicates and Operators

-- T-SQL: IN, BETWEEN, EXISTS, LIKE

-- IN
select orderid, empid, orderdate
from sales.Orders
where orderid IN (10248, 10249, 10250);

-- BETWEEN
select orderid, empid, orderdate
from sales.Orders
where orderid BETWEEN 10248 AND 10250;

-- LIKE
SELECT * FROM HR.Employees
where lastname like 'D'

SELECT * FROM HR.Employees
where lower(lastname) like 'd%'

SELECT * FROM HR.Employees
where lower(lastname) like 'd_'

-- Operators
/*
	()
	*,/,%
	+ (Positive), - (Negative), + (Addition), + (Concatenation), - (Subtraction)
	=, >, <, >=, <=, <>, !>, !<, !=	(comparision)
	NOT
	AND
	BETWEEN, IN, LIKE, OR
	= (Assignment)
*/

select * from sales.Orders
where custid = 1
and empid in (1, 3, 5)
or custid = 85
and empid in (2, 4, 6)

select * from sales.Orders
where (custid = 1
and empid in (1, 3, 5))
or (custid = 85
and empid in (2, 4, 6))

select 10 + 2 * 3

select (10 + 2) * 3

-- CASE expressions

-- SIMPLE Case
-- SEARCHED Case

select * from Production.Products

-- SIMPLE Case
select productid, productname
	, case categoryid
		WHEN 1 THEN 'Beverages'
		WHEN 2 THEN 'Condiments'
		ELSE 'Unknown'
	END as categoryname
from Production.Products

-- SEARCHED Case
select orderid, custid, val,
	case
		when val < 1000.00 THEN 'Less than 1000'
		when val BETWEEN 1000.00 AND 3000.00 THEN 'bETWEEN 1000 AND 3000'
		when val > 3000.00 THEN 'mORE THAN 3000'
		ELSE 'Unknown'
	end as valuecategory
from [Sales].[OrderValues]

-- NULL
-- 91
select * from sales.customers

-- 3
select * from sales.customers
where region='WA'

-- 28
select * from sales.customers
where region<>'WA'

-- 60 - correct!
select * from sales.customers
where region IS NULL

-- wrong!
select * from sales.customers
where region = NULL

-- 31
select * from sales.customers
where region IS NOT NULL

INSERT INTO testnull VALUES (1, 'fulvio', 16)
INSERT INTO testnull VALUES (2, 'sandra', null)
INSERT INTO testnull(id, name) VALUES (3, 'fabio')

select * from testnull
where age is null

select * from testnull
order by age

