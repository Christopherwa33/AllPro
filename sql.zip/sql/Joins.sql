select * from sales.Customers

select * from hr.Employees

-- Cross JOIN

-- ANSI SQL-92 Syntax
select custid, empid
from sales.Customers CROSS JOIN HR.Employees

-- ANSI SQL-89 Syntax
select c.custid, e.empid
from sales.Customers as c, HR.Employees as e

-- Inner Join

-- ANSI SQL-92 Syntax
select e.empid, e.firstname, e.lastname, o.orderid
from hr.Employees as e INNER JOIN Sales.Orders as o
on e.empid = o.empid

-- ANSI SQL-89 Syntax
select e.empid, e.firstname, e.lastname, o.orderid
from hr.Employees as e, Sales.Orders as o
where e.empid = o.empid and e.empid=90

-- more tables involved...
select 
	e.empid, e.firstname, e.lastname, o.orderid, od.productid
from
	hr.Employees as e 
JOIN
	Sales.Orders as o
on 
	e.empid = o.empid 
JOIN 
	Sales.OrderDetails as od
on 
	o.orderid = od.orderid

-- OUTER Joins

-- LEFT OUTER JOIN
select c.custid, c.companyname, o.orderid
from 
	sales.Customers as c
LEFT OUTER JOIN
	sales.Orders as o
ON
	c.custid = o.custid

select c.custid, c.companyname, o.orderid
from 
	sales.Customers as c
LEFT OUTER JOIN
	sales.Orders as o
ON
	c.custid = o.custid
WHERE o.orderid is null;

-- RIGHT
select c.custid, c.companyname, o.orderid
from 
	sales.Customers as c
RIGHT OUTER JOIN
	sales.Orders as o
ON
	c.custid = o.custid

select c.custid, c.companyname, o.orderid
from 
	sales.Customers as c
JOIN
	sales.Orders as o
ON
	c.custid = o.custid

-- FULL OUTER JOIN
select c.custid, c.companyname, o.orderid
from 
	sales.Customers as c
FULL OUTER JOIN
	sales.Orders as o
ON
	c.custid = o.custid


/*
7. Return all customers, and for each return a Yes/No value depending on whether the customer placed
an order on February 12, 2016.
Tables involved: Sales.Customers and Sales.Orders
Output: custid, companyname, HasOrderOn20160212
*/

SELECT c.custid, companyname
	, case when o.orderid is not null 
		then 'YES' ELSE 'NO' END as HasOrderOn20160212
	FROM sales.CUSTOMERS C
left outer join sales.Orders as o
on o.custid = c.custid
and o.orderdate = '20160212'