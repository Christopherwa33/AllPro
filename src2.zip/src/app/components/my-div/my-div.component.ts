import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-div',
  templateUrl: './my-div.component.html',
  styleUrls: ['./my-div.component.css']
})
export class MyDivComponent implements OnInit {
    @Input()
    public counter: number = 0;

    @Output()
    public counterChange: EventEmitter<number> = new EventEmitter<number>();

    constructor() { }

    ngOnInit(): void {
    }

    public incrementaCounter() {
        this.counter++;
        this.counterChange.emit(this.counter);
    }

}
